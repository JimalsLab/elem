using UnityEngine;

public class SettingsManager : MonoBehaviour {
    
    public Difficulty difficulty;
    public int sound;
    public bool fullscreen;
    public int quality;
}
