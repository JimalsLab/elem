public enum Difficulty{
    EASY,
    NORMAL,
    HARD,
    STEPPING_ON_LEGO,
}
