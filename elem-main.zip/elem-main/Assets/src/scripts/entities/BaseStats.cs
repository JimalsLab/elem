public class BaseStats{
    public int Life {get;set;}
    public int Attack {get;set;}
    public int MagicPoints {get;set;}
    public int ActionPoints {get;set;}
    public int MovementPoints {get;set;}
    public int Armour {get;set;}
    public int MagicRes {get;set;}
    public int FireRes {get;set;}
    public int ColdRes {get;set;}
    public int LightningRes {get;set;}
    public int ChaosRes {get;set;}
}
