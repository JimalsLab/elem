public enum TileType
{
    XXXX,
    GGGG,
    DGGG,
    GDGG,
    GGDG,
    GGGD,
    DDDD
}
