using UnityEngine;

public class Map : MonoBehaviour {
        public int GrassPercentage {get; set;} = 50;
        public int DirtPercentage {get; set; } = 25;
}
