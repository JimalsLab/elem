public enum Perk {
    EXPLODING_PROJECTILES,
    RANGE,
    CHEAP_SHOP
}
