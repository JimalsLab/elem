public enum AIMode{
    EASY,
    PASSIVE,
    FLEEING,
    AGGRESSIVE,
    SMART
}
