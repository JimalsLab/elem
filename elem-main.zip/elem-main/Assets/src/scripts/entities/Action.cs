public enum Action {
    AUTO_ATTACK,
    DASH,
    SHIELD
}
