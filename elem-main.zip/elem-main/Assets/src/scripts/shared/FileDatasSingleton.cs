using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FileDatasSingleton : MonoBehaviour
{

    //// Static singleton instance
    //private static FileDatasSingleton instance;

    //// Static singleton property
    //public static FileDatasSingleton Instance
    //{
    //    // ajout ET cr�ation du composant � un GameObject nomm� "SingletonHolder" 
    //    get { return instance ?? (instance = new GameObject("SingletonHolder").AddComponent()); }
    //    private set { instance = value; }
    //}

    //void Awake()
    //{
    //    DontDestroyOnLoad(gameObject);//le GameObject qui porte ce script ne sera pas d�truit
    //}

    ////m�thode appel�e par les "clients" de cette classe 
    //public void loadFile()
    //{

    //}
}